﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    public class Imovel
    {
        public int Id { get; set; }
        public int IdProprietario { get; set; }
        public int IdFinalidade { get; set; }
        public int IdCategoria { get; set; }
        public string Padrao { get; set; }
        public string Endereco { get; set; }
        public string NumeroEndereco { get; set; }
        public string IdCep { get; set; }
        public string Complemento { get; set; }
        public int IdBairro { get; set; }
        public int IdMunicipio { get; set; }
        public int IdEstado { get; set; }
        public int IdEstadoImovel { get; set; }
        public int IdDormitorio { get; set; }
        public int IdPosicao { get; set; }
        public char Garagem { get; set; }
        public string NomeEdificio { get; set; }
        public string NomeConstrutora { get; set; }
        public string DataConstrucao { get; set; }
        public string Situacao { get; set; }
        public char Financiamento { get; set; }
        public double ValorImovel { get; set; }
        public double ValorCondominio { get; set; }
        public char Exclusividade { get; set; }
        public char Vazio { get; set; }
        public string CdPrefeitura { get; set; }
        public string CdCartorio { get; set; }
        public string CdRegistro { get; set; }
        public char Documentacao { get; set; }
        public char Elevador { get; set; }
        public string LocalChaves { get; set; }
        public double AreaUtil { get; set; }
        public double AreaTotal { get; set; }
        public double AreaTerreno { get; set; }
        public char Eletricidade { get; set; }
        public char Gas { get; set; }
        public char Agua { get; set; }
        public char Portaria { get; set; }
        public DateTime DataAlteracao { get; set; }
        public char Destaque { get; set; }

        public Imovel()
        {
        }
        public Imovel(int _id, int _idProprietario, int _idFinalidade, int _idCategoria, string _padrao,
            string _endereco, string _numeroEndereco, string _idCep, string _complemento, int _idBairro, int _idMunicipio,
            int _idEstado, int _idDormitorio, int _idPosicao, char _garagem, string _nomeEdificio, string _nomeConstrutora,
            string _dataConstrucao, string _situacao, char _financiamento, double _valorImovel, double _valorCondominio,
            char _exclusividade, char _vazio, string _cdPrefeitura, string _cdCartorio, string _cdRegistro, 
            char _documentacao, char _elevador, string _localChaves, double _areaUtil, double _areaTotal, 
            double _areaTerreno, char _eletricidade, char _gas, char _agua, char _portaria, char _destaque)
        {
            Id = _id;
            IdProprietario = _idProprietario;
            IdFinalidade = _idFinalidade;
            IdCategoria = _idCategoria;
            Padrao = _padrao;
            Endereco = _endereco;
            NumeroEndereco = _numeroEndereco;
            IdCep = _idCep;
            Complemento = _complemento;
            IdBairro = _idBairro;
            IdMunicipio = _idMunicipio;
            IdEstado = _idEstado;
            IdDormitorio = _idDormitorio;
            IdPosicao = _idPosicao;
            Garagem = _garagem;
            NomeEdificio = _nomeEdificio;
            NomeConstrutora = _nomeConstrutora;
            DataConstrucao = _dataConstrucao;
            Situacao = _situacao;
            Financiamento = _financiamento;
            ValorImovel = _valorImovel;
            ValorCondominio = _valorCondominio;
            Exclusividade = _exclusividade;
            Vazio = _vazio;
            CdPrefeitura = _cdPrefeitura;
            CdCartorio = _cdCartorio;
            CdRegistro = _cdRegistro;
            Documentacao = _documentacao;
            Elevador = _elevador;
            LocalChaves = _localChaves;
            AreaUtil = _areaUtil; 
            AreaTotal = _areaTotal; 
            AreaTerreno = _areaTerreno;
            Eletricidade = _eletricidade;
            Gas = _gas;
            Agua = _agua;
            Portaria = _portaria;
            Destaque = _destaque;
            DataAlteracao = DateTime.Now;
        }
    }
}
