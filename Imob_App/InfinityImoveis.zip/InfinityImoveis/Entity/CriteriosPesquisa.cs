﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    public class CriteriosPesquisa
    {
        public CriteriosPesquisa(string _estado, string _municipio, string _bairro, string _finalidade, string _categoria, string _dormitorio, 
            string _valorMenor, string _valorMaior)
        {
            Estado = _estado;
            Municipio = _municipio;
            Bairro = _bairro;
            Finalidade = _finalidade;
            Categoria = _categoria;
            Dormitorio = _dormitorio;
            ValorMenor = _valorMenor;
            ValorMaior = _valorMaior;
        }

        public string Estado { get; set; }
        public string Municipio { get; set; }
        public string Bairro { get; set; }
        public string Finalidade { get; set; }
        public string Categoria { get; set; }
        public string Dormitorio { get; set; }
        public string ValorMaior { get; set; }
        public string ValorMenor { get; set; }

        public CriteriosPesquisa()
        {
        }
    }
}
