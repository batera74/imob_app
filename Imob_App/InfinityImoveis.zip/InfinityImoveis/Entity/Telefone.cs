﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    class Telefone
    {
        public int Id { get; set; }
        public int IdProprietario { get; set; }
        public int IdTipo { get; set; }
        public string Numero { get; set; }
    }
}
