﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    class Proprietario
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public string Profissao { get; set; }
        public int Cpf { get; set; }
        public int Rg { get; set; }
        public string Email { get; set; }
        public string NomeConjuge { get; set; }
        public string SobrenomeConjuge { get; set; }
    }
}
