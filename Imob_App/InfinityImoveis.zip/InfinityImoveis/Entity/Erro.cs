﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    public class Erro
    {
        public DateTime DtOcorrido { get; set; }
        public string DsErro { get; set; }
        public string Stack { get; set; }
        public string Metodo { get; set; }

        public Erro()
        {
        }

        public Erro(DateTime _dt_ocorrido, string _ds_erro, string _stack, string _metodo)
        {
            DtOcorrido = _dt_ocorrido;
            DsErro = _ds_erro;
            Stack = _stack;
            Metodo = _metodo;
        }
    }
}
