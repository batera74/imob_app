﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    public class User
    {
        public User(string _user, string _password)
        {
            Username = _user;
            Password = _password;
        }

        public User()
        {
        }

        public int IdUser { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
