﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Entity
{
    public class ImovelDetalhe
    {
        public ImovelDetalhe()
        {
        }

        public ImovelDetalhe(DataTable _dtImovel)
        {
            Categoria = _dtImovel.Rows[0]["Categoria"].ToString() + " " +
            _dtImovel.Rows[0]["Dormitorios"].ToString() + " dormitórios";
            Endereco = _dtImovel.Rows[0]["Endereco"].ToString();
            Cidade = _dtImovel.Rows[0]["Cidade"].ToString();
            Valor = Convert.ToDouble(_dtImovel.Rows[0]["Valor"].ToString()).ToString("C2");

            try
            {
                ValorCondominio = Convert.ToDouble(_dtImovel.Rows[0]["Condominio"].ToString()).ToString("C2");
            }
            catch
            {
                ValorCondominio = "Não Informado";
            }

            try
            {
                ValorIPTU = Convert.ToDouble(_dtImovel.Rows[0]["IPTU"].ToString()).ToString("C2");
            }
            catch
            {
                ValorIPTU = "Não Informado";
            }

            try
            {
                Banheiros = _dtImovel.Rows[0]["Banheiros"].ToString();
            }
            catch
            {
                Banheiros = "Não Informado";
            }
            
            Id = Convert.ToInt16(_dtImovel.Rows[0]["id"].ToString());

            try
            {
                Garagem = _dtImovel.Rows[0]["ds_garagem"].ToString();
            }
            catch
            {
                Garagem = "Não Informado";
            }

            try
            {
                Portaria = _dtImovel.Rows[0]["ds_portaria"].ToString();
            }
            catch
            {
                Portaria = "Não Informado";
            }

            Elevador = PossuiCaracteristica(_dtImovel.Rows[0]["ic_elevador"].ToString());
            Vazio = PossuiCaracteristica(_dtImovel.Rows[0]["ic_vazio"].ToString());
        }

        public int Id { get; set; }
        public string Categoria { get; set; }
        public string Dormitorios { get; set; }
        public string Endereco { get; set; }
        public string Cidade { get; set; }
        public string Valor { get; set; }
        public string ValorCondominio { get; set; }
        public string Banheiros { get; set; }
        public string Garagem { get; set; }
        public string Portaria { get; set; }
        public string Elevador { get; set; }
        public string Vazio { get; set; }
        public string ValorIPTU { get; set; }

        private string PossuiCaracteristica(string _caracteristica)
        {
            return Convert.ToInt16(_caracteristica) > 0 ? "Sim" : "Não";
        }
    }
}
