﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    public class ImovelBusca
    {
        public ImovelBusca()
        {
        }

        public ImovelBusca(int _estado, int _municipio, int _bairro, int _finalidade, int _categoria, int _dormitorio, int vlMaior, int vlMenor, int id)
        {
            Estado = _estado;
            Municipio = _municipio;
            Bairro = _bairro;
            Finalidade = _finalidade;
            Categoria = _categoria;
            Dormitorio = _dormitorio;
            VlMaior = vlMaior;
            VlMenor = vlMenor;
            ID = id;
        }

        public int Estado { get; set; }
        public int Municipio { get; set; }
        public int Bairro { get; set; }
        public int Finalidade { get; set; }
        public int Categoria { get; set; }
        public int Dormitorio { get; set; }
        public int VlMaior { get; set; }
        public int VlMenor { get; set; }
        public int ID { get; set; }
    }
}
