﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using System.Configuration;

public partial class Imagens : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CarregarDatalist();
        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        int id = Imagem.InserirImagem(Convert.ToInt32(Request.QueryString["id_imovel"]));
        string alerta = Imagem.UploadImagem(File1, id);
        CarregarDatalist();
        Response.Write("<script>alert('" + alerta + "');</script>");
    }

    public string LinkImagem()
    {
        return ConfigurationManager.AppSettings["PathImagem"] + "{0}";
    }

    public void DeletarImagem(int _id_imagem)
    {
        Imagem.DeletarImagem(_id_imagem, Convert.ToInt16(Request.QueryString["id_imovel"]));
        CarregarDatalist();
    }

    protected void CarregarDatalist()
    {
        dtlImagens.DataSource = Imagem.CarregarImagens(Convert.ToInt16(Request.QueryString["id_imovel"]));
        dtlImagens.DataBind();
    }

    protected void Unnamed1_Click(object sender, EventArgs e)
    {
        DeletarImagem(Convert.ToInt32((((LinkButton)sender).Attributes["id_imagem"])));
    }

    protected void dtlImagens_ItemDataBound1(object sender, DataListItemEventArgs e)
    {
        ((LinkButton)e.Item.Controls[3]).Attributes["id_imagem"] = DataBinder.Eval(e.Item.DataItem, "ID").ToString();
    }
}