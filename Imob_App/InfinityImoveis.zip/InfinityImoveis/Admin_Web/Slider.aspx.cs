﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using System.Text;
using System.Data;
using System.IO;
using System.Configuration;

public partial class Slider : BLL.BasePage2
{
    string alerta = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CarregarDatalist();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        alerta = BLL.Slider.UploadSlider(File1);
        //CarregarDatalist();

        if (!alerta.Equals("Erro!"))
        {
            if (!alerta.Equals("Arquivo Vazio!"))
                Response.Write("<script>alert('Arquivo carregado com sucesso!');</script>");
            else
                Response.Write("<script>alert('Arquivo Vazio!');</script>");
        }
        else
            Response.Write("<script>alert('Erro!');</script>");
    }

    public void Deletar(int _id_slider)
    {
        BLL.Slider.Deletar(_id_slider);
        CarregarDatalist();
    }

    protected void CarregarDatalist()
    {
        dtlImagens.DataSource = BLL.Slider.Carregar(false);
        dtlImagens.DataBind();
    }

    protected void lnkExcluir_Click(object sender, EventArgs e)
    {
        Deletar(Convert.ToInt32((((LinkButton)sender).Attributes["id_slide"])));
    }

    protected void dtlImagens_ItemDataBound1(object sender, DataListItemEventArgs e)
    {
        ((LinkButton)e.Item.FindControl("lnkExcluir")).Attributes["id_slide"] = DataBinder.Eval(e.Item.DataItem, "ID").ToString();
        ((LinkButton)e.Item.FindControl("lnkSalvar")).Attributes["id_slide"] = DataBinder.Eval(e.Item.DataItem, "ID").ToString();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        bool erro = false;
        StringBuilder sb = new StringBuilder();
        sb.Append("Favor preencher: ");

        if (File1.PostedFile == null)
        {
            sb.Append("Imagem para Upload");
            erro = true;
        }

        if (txt1_.Text.Equals(""))
        {
            sb.Append(sb.ToString().Equals("Favor preencher: ") ? sb.Append("Texto 1 ") : sb.Append(" | Texto 1"));
            erro = true;
        }

        if (txt2_.Text.Equals(""))
        {
            sb.Append(sb.ToString().Equals("Favor preencher: ") ? sb.Append("Texto 2 ") : sb.Append(" | Texto 2"));
            erro = true;
        }

        if (erro)
            lblErro.Text = sb.ToString();
        else
        {
            alerta = BLL.Slider.UploadSlider(File1);
            BLL.Slider.Salvar(alerta, Convert.ToInt16(((DataTable)BLL.Slider.Salvar(txt1_.Text, txt2_.Text, chkAtivo.Checked)).Rows[0]["ID"]));
            
            string[] files = Directory.GetFiles(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathSlider"] + "Temp/"));

            foreach (string file in files)
                File.Delete(file);

            CarregarDatalist();
        }

    }
    protected void dtlImagens_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName.Equals("save"))
        {
            int id_slide = Convert.ToInt16(((LinkButton)e.Item.FindControl("lnkSalvar")).Attributes["id_slide"]);
            string texto1 = ((TextBox)e.Item.FindControl("txt1")).Text;
            string texto2 = ((TextBox)e.Item.FindControl("txt2")).Text;
            bool ativo = ((CheckBox)e.Item.FindControl("chkAtivo")).Checked;
            BLL.Slider.Salvar(id_slide, texto1, texto2, ativo);
        }
    }

    public string LinkImagem()
    {
        return ConfigurationManager.AppSettings["PathSlider"] + "{0}";
    }
}