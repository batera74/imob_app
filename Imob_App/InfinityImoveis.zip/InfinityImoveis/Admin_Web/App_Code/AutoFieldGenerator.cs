﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.DynamicData;
using System.Web.UI.WebControls;
using System.Collections;
using System.Web.DynamicData.ModelProviders;

public class AutoFieldGenerator : IAutoFieldGenerator
{

    private MetaTable _table;

    public AutoFieldGenerator(MetaTable table)
    {
        _table = table;
    }

    #region IAutoFieldGenerator Members

    public ICollection GenerateFields(Control control)
    {
        // Auto-generate fields from metadata.
        var fields = new List<DynamicField>();
        foreach (MetaColumn column in _table.Columns)
        {
            // Skip column that shouldn't be scaffolded
            if (!column.Scaffold) continue;

            // Don't display long string in controls that show multiple items
            // REVIEW: we should avoid hard coding a list of control, but IDataBoundControl does not give us this info
            if (column.IsLongString && control is GridView)
                continue;

            // If it's a Many To Many column, use our special field template
            string uiHint = null;
            if (column.Provider.Association != null && column.Provider.Association.Direction == AssociationDirection.ManyToMany)
            {
                uiHint = "ManyToMany";
            }

            if (column.Name == "Imagem")
            {
                uiHint = "FileUpload";
            }

            fields.Add(new DynamicField() { DataField = column.Name, UIHint = uiHint });
        }

        return fields;
    }
    #endregion
}
