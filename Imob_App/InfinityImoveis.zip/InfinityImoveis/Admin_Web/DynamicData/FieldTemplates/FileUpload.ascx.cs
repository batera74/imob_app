﻿using System;
using System.Web.UI;
using System.Web.DynamicData;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.ComponentModel;

public partial class DynamicData_FieldTemplates_FileUpload : FieldTemplateUserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //btn.Attributes["onClick"] = "OpenInnerFrame('img', '../Imagens.aspx?id_imovel='" + Session["id"].ToString() + "', true)'";
    }

    protected override void OnDataBinding(EventArgs e)
    {
        base.OnDataBinding(e);

        // Get the real entity from the wrapper
        object entity = ((ICustomTypeDescriptor)Row).GetPropertyOwner(null);

        // Get the collection and make sure it's loaded
        var entityCollection = (RelatedEnd)Column.EntityTypeProperty.GetValue(entity, null);
        entityCollection.Load();

        Session["id"] = ((imobiliariainfinityModel.Imovel)(entity)).id;
       // btn.Attributes.Add("onclick", "OpenInnerFrame(''img'', ''../Imagens.aspx?id_imovel=" + Session["id"].ToString() + ", true)");

        // Bind the repeater to the list of children entities
    }

    public override Control DataControl { get { return null/*Button1*/; } }

    public string LinkImagem()
    {
        return "../Imagens.aspx?id_imovel=" + Session["id"].ToString();
    }
}