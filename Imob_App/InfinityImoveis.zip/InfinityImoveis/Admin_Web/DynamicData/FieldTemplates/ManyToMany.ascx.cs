﻿using System;
using System.Web.UI;
using System.Web.DynamicData;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.ComponentModel;

public partial class DynamicData_FieldTemplates_ManyToMany : FieldTemplateUserControl {

    protected override void OnDataBinding(EventArgs e) {
        base.OnDataBinding(e);

        // Get the real entity from the wrapper
        object entity = ((ICustomTypeDescriptor)Row).GetPropertyOwner(null);

        // Get the collection and make sure it's loaded
        var entityCollection = (RelatedEnd)Column.EntityTypeProperty.GetValue(entity, null);
        entityCollection.Load();

        // Bind the repeater to the list of children entities
        Repeater1.DataSource = entityCollection;
        Repeater1.DataBind();
    }

    public override Control DataControl { get { return Repeater1; } }
}

