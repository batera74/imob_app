﻿using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.DynamicData;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.ComponentModel;

public partial class DynamicData_FieldTemplates_ManyToMany_EditField : FieldTemplateUserControl {

    public void Page_Load(object sender, EventArgs e) {
        // Register for the DataSource's updating event
        var ds = (EntityDataSource)this.FindDataSourceControl();

        // This field template is used both for Editing and Inserting
        ds.Updating += new EventHandler<EntityDataSourceChangingEventArgs>(DataSource_UpdatingOrInserting);
        ds.Inserting += new EventHandler<EntityDataSourceChangingEventArgs>(DataSource_UpdatingOrInserting);
    }

    void DataSource_UpdatingOrInserting(object sender, EntityDataSourceChangingEventArgs e) {
        MetaTable childTable = ChildrenColumn.ChildTable;

        // Comments assume employee/territory for illustration, but the code is generic

        // Get the collection of territories for this employee
        var entityCollection = (RelatedEnd)Column.EntityTypeProperty.GetValue(e.Entity, null);

        // In Edit mode, make sure it's loaded (doesn't make sense in Insert mode)
        if (Mode == DataBoundControlMode.Edit)
            entityCollection.Load();

        // Get an IList from it (i.e. the list of territories for the current employee)
        // REVIEW: we should be using EntityCollection directly, but EF doesn't have a
        // non generic type for it. They will add this in vnext
        IList entityList = ((IListSource)entityCollection).GetList();

        // Go through all the territories (not just those for this employee)
        foreach (var childEntity in childTable.GetQuery(e.Context)) {

            // Check if the employee currently has this territory
            bool isCurrentlyInList = entityList.Contains(childEntity);

            // Find the checkbox for this territory, which gives us the new state
            string pkString = childTable.GetPrimaryKeyString(childEntity);
            ListItem listItem = CheckBoxList1.Items.FindByValue(pkString);
            if (listItem == null)
                continue;

            // If the states differs, make the appropriate add/remove change
            if (listItem.Selected) {
                if (!isCurrentlyInList)
                    entityList.Add(childEntity);
            }
            else {
                if (isCurrentlyInList)
                    entityList.Remove(childEntity);
            }
        }
    }

    protected void CheckBoxList1_DataBound(object sender, EventArgs e) {
        MetaTable childTable = ChildrenColumn.ChildTable;

        // Comments assume employee/territory for illustration, but the code is generic

        IList entityList = null;
        ObjectContext objectContext = null;

        if (Mode == DataBoundControlMode.Edit) {
            // Get the real entity from the wrapper
            object entity = ((ICustomTypeDescriptor)Row).GetPropertyOwner(null);

            // Get the collection of territories for this employee and make sure it's loaded
            var entityCollection = (RelatedEnd)Column.EntityTypeProperty.GetValue(entity, null);
            entityCollection.Load();

            // Get an IList from it (i.e. the list of territories for the current employee)
            // REVIEW: we should be using EntityCollection directly, but EF doesn't have a
            // non generic type for it. They will add this in vnext
            entityList = ((IListSource)entityCollection).GetList();

            // Get the current ObjectContext
            // REVIEW: this is quite a dirty way of doing this. Look for better alternative
            var objectQuery = (ObjectQuery)entityCollection.GetType().GetMethod(
                "CreateSourceQuery").Invoke(entityCollection, null);
            objectContext = objectQuery.Context;
        }

        // Go through all the territories (not just those for this employee)
        foreach (var childEntity in childTable.GetQuery(objectContext)) {
            // Create a checkbox for it
            var listItem = new ListItem(
                childTable.GetDisplayString(childEntity),
                childTable.GetPrimaryKeyString(childEntity));

            // Make it selected if the current employee has that territory
            if (Mode == DataBoundControlMode.Edit) {
                listItem.Selected = entityList.Contains(childEntity);
            }

            CheckBoxList1.Items.Add(listItem);
        }
    }

    public override Control DataControl { get { return CheckBoxList1; } }
}
