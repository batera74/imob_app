﻿using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.DynamicData;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.ComponentModel;

public partial class DynamicData_FieldTemplates_FileUpload : FieldTemplateUserControl
{

    public override Control DataControl { get { return null; } }

    protected void Button1_Click(object sender, EventArgs e)
    {

    }

    protected override void OnDataBinding(EventArgs e)
    {
        base.OnDataBinding(e);

        // Get the real entity from the wrapper
        if (((ICustomTypeDescriptor)Row) != null)
        {
            object entity = ((ICustomTypeDescriptor)Row).GetPropertyOwner(null);

            // Get the collection and make sure it's loaded
            var entityCollection = (RelatedEnd)Column.EntityTypeProperty.GetValue(entity, null);
            entityCollection.Load();

            Session["id"] = ((imobiliariainfinityModel.Imovel)(entity)).id;
            Session["novo"] = false;
        }
        else
            Session["novo"] = true;
    }


    public string LinkImagem()
    {
        if (!(bool)Session["novo"])
        {
            return "OpenInnerFrame(\"img\", \"../Imagens.aspx?id_imovel=" + Session["id"].ToString() + "\", true)";
        }
        return "";
    }
}