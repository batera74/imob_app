﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data;
using DAL.Configuration;

namespace DAL
{
    public static class DataAccess
    {
        //construtor
        static DataAccess()
        {
        }

        //método que criará o comando que realizará a consulta no banco de dados
        //Ele recebe o texto do comando, o tipo (Text, SP e TableDirect) e uma lista de parametros
        public static DbCommand CreateCommand(String cmmdText, CommandType cmmdType, List<DbParameter> listParameter)
        {
            try
            {
                DbProviderFactory factory = DbProviderFactories.GetFactory(ConnectionDB.ProvName);
                DbConnection conn = factory.CreateConnection();

                conn.ConnectionString = ConnectionDB.ConnString;

                DbCommand comm = conn.CreateCommand();
                comm.CommandText = cmmdText;
                comm.CommandType = cmmdType;

                if (listParameter != null)
                {
                    foreach (DbParameter param in listParameter)
                        comm.Parameters.Add(param);
                }

                return comm;
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());

                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@DS_ERRO", System.Data.DbType.String, exc.DsErro));
                param.Add(DataAccess.CreateParameter("@DT_ERRO", System.Data.DbType.DateTime, exc.DtOcorrido));
                param.Add(DataAccess.CreateParameter("@DS_STACK", System.Data.DbType.String, exc.Stack));
                param.Add(DataAccess.CreateParameter("@DS_METODO", System.Data.DbType.String, exc.Metodo));

                DataAccess.executeCommand("PRC_INS_ERRO_LOG", CommandType.StoredProcedure,
                    param, TypeCommand.ExecuteDataTable);

                return null;
            }
        }
        
        //método que cria os parametros da consulta
        //Ele recebe o nome do parametro, o tipo (String, Int, Datetime e etc) e o valor
        public static DbParameter CreateParameter(String nameParameter, DbType typeParameter, object valueParameter)
        {
            try
            {
                DbProviderFactory factory = DbProviderFactories.GetFactory(ConnectionDB.ProvName);
                DbParameter param = factory.CreateParameter();

                param.ParameterName = nameParameter;
                param.DbType = typeParameter;
                param.Value = valueParameter;

                return param;
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());

                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@DS_ERRO", System.Data.DbType.String, exc.DsErro));
                param.Add(DataAccess.CreateParameter("@DT_ERRO", System.Data.DbType.DateTime, exc.DtOcorrido));
                param.Add(DataAccess.CreateParameter("@DS_STACK", System.Data.DbType.String, exc.Stack));
                param.Add(DataAccess.CreateParameter("@DS_METODO", System.Data.DbType.String, exc.Metodo));

                DataAccess.executeCommand("PRC_INS_ERRO_LOG", CommandType.StoredProcedure,
                    param, TypeCommand.ExecuteDataTable);

                return null;
            }
        }

        //método que executa o comando que acessa o banco de dados.
        //Ele recebe o texto do comando, o tipo (Reader, NonQuery, Scalar ou DataTable), a lista de parametros 
        //e o tipo do comando de acordo com a enum para retornar o objeto de acordo com o desejado.
        public static Object executeCommand(String cmmdText, CommandType cmmdType, List<DbParameter> listParameter, TypeCommand typeCmmd)
        {
            DbCommand command = CreateCommand(cmmdText, cmmdType, listParameter);
            Object objRetorno = null;

            try
            {
                command.Connection.Open();

                switch (typeCmmd)
                {
                    case TypeCommand.ExecuteNonQuery:
                        //retorna o numero de linhas resultantes da consulta
                        objRetorno = command.ExecuteNonQuery();
                        break;
                    case TypeCommand.ExecuteReader:
                        //Retorna um DataReader
                        objRetorno = command.ExecuteReader(CommandBehavior.CloseConnection);
                        break;
                    case TypeCommand.ExecuteScalar:
                        //Retorna uma tabela
                        objRetorno = command.ExecuteScalar();
                        break;
                    case TypeCommand.ExecuteDataTable:
                        //Executa o comando e retorna a consulta dentro de um DataTable
                        DataTable dt = new DataTable();
                        DbDataReader dr = command.ExecuteReader();
                        dt.Load(dr);
                        dr.Close();
                        objRetorno = dt;
                        break;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (typeCmmd != TypeCommand.ExecuteReader)
                {
                    //Obrigatoriamente fichar a conexão com o BD após qualquer consulta
                    command.Connection.Close();
                }
            }

            return objRetorno;

        }
    }
}
