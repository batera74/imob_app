﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    public enum TypeCommand
    {
        ExecuteNonQuery,
        ExecuteReader,
        ExecuteScalar,
        ExecuteDataTable
    }
}
