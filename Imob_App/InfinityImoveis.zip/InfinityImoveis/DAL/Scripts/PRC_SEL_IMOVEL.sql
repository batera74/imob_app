USE imobiliariainfinity
GO

IF EXISTS ( SELECT 1 FROM sys.objects WHERE OBJECT_ID = object_id(N'[DBO].[PRC_SEL_IMOVEL]')
								      AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE [PRC_SEL_IMOVEL]
END
GO								   

CREATE PROCEDURE [dbo].[PRC_SEL_IMOVEL](@ID_IMOVEL INT)
AS
  BEGIN
		SELECT (
		SELECT imov.id, (bai.nome + ' - ' + mun.nome + '/' + est.cd_uf) Cidade, fin.nome Finalidade,
		cat.nome Categoria, (imov.ds_endereco + ' ' + imov.ds_numeroEndereco + '/' + imov.ds_complemento) Endereco, 
		imov.ds_banheiro Banheiros, imov.id_dormitorio as Dormitorios, imov.vl_imovel Valor, 
		imov.vl_condominio Condominio, imov.vl_iptu IPTU, imov.ic_financiamento, imov.ds_garagem, imov.ds_portaria,		
		imov.ic_vazio, imov.vl_areaTotal, imov.vl_areaUtil, imov.ic_elevador
		FROM Imovel imov
		LEFT JOIN Estado est ON imov.id_estado = est.id
		LEFT JOIN Municipio mun ON imov.id_municipio = mun.id		
		LEFT JOIN Bairro bai ON imov.id_bairro = bai.id
		LEFT JOIN Finalidade fin ON imov.id_finalidade = fin.id
		LEFT JOIN Categoria cat ON imov.id_categoria = cat.id
		WHERE imov.id = @ID_IMOVEL
	    FOR XML PATH('Imovel'), TYPE ),
	    (		
		SELECT acab.ds_item FROM Imovel imov
		LEFT JOIN ImovelAcabamento imovacab ON imovacab.id_imovel = imov.id
		LEFT JOIN Acabamento acab on imovacab.id_acabamento = acab.id 
		WHERE imov.id = @ID_IMOVEL
		ORDER BY acab.ds_item
		FOR XML PATH('Acabamento'), TYPE ),
		(
		SELECT arm.ds_item FROM Imovel imov
		LEFT JOIN ImovelArmarios imovarm ON imovarm.id_imovel = imov.id
		LEFT JOIN Armarios arm on imovarm.id_armarios = arm.id 
		WHERE imov.id = @ID_IMOVEL
		ORDER BY arm.ds_item
		FOR XML PATH('Armarios'), TYPE ),
		(
		SELECT inti.ds_item FROM Imovel imov
		LEFT JOIN ImovelIntima imovinti ON imovinti.id_imovel = imov.id
		LEFT JOIN Intima inti on imovinti.id_intima = inti.id 
		WHERE imov.id = @ID_IMOVEL
		ORDER BY inti.ds_item
		FOR XML PATH('Intima'), TYPE ),
		(
		SELECT lazer.ds_item FROM Imovel imov
		LEFT JOIN ImovelLazer imovlazer ON imovlazer.id_imovel = imov.id
		LEFT JOIN Lazer lazer on imovlazer.id_lazer = lazer.id 
		WHERE imov.id = @ID_IMOVEL
		ORDER BY lazer.ds_item
		FOR XML PATH('Lazer'), TYPE ),
		(
		SELECT serv.ds_item FROM Imovel imov
		LEFT JOIN ImovelServicos imovserv ON imovserv.id_imovel = imov.id
		LEFT JOIN Servicos serv on imovserv.id_servicos = serv.id 
		WHERE imov.id = @ID_IMOVEL
		ORDER BY serv.ds_item
		FOR XML PATH('Servicos'), TYPE ),
		(
		SELECT soc.ds_item FROM Imovel imov
		LEFT JOIN ImovelSocial imovsoc ON imovsoc.id_imovel = imov.id
		LEFT JOIN Social soc on imovsoc.id_social = soc.id 
		WHERE imov.id = @ID_IMOVEL
		ORDER BY soc.ds_item
		FOR XML PATH('Social'), TYPE ),
		(
		SELECT nome FROM Imagem where id_imovel = @ID_IMOVEL
		FOR XML PATH('Imagem'), TYPE )
		FOR XML PATH(''),
		ROOT('root')
  END 