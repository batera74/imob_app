USE imobiliariainfinity
GO

IF EXISTS (SELECT 1 FROM sys.objects WHERE OBJECT_ID = object_id(N'[DBO].[PRC_SEL_IMAGEM_IMOVEL]')
								      AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE [PRC_SEL_IMAGEM_IMOVEL]
END
GO								   

CREATE PROCEDURE [dbo].[PRC_SEL_IMAGEM_IMOVEL]
(@ID_IMOVEL INT)
AS
  BEGIN
	SELECT id ID, nome Imagem FROM Imagem img WHERE id_imovel = @ID_IMOVEL
  END