USE imobiliariainfinity
GO

IF EXISTS ( SELECT 1 FROM sys.objects WHERE OBJECT_ID = object_id(N'[DBO].[PRC_BUSCA_RAPIDA_IMOVEL_ID]')
								      AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE [PRC_BUSCA_RAPIDA_IMOVEL_ID]
END
GO								   

CREATE PROCEDURE [PRC_BUSCA_RAPIDA_IMOVEL_ID](@ID INT)
AS
  BEGIN
		
		SELECT imov.id Id, est.cd_uf Estado, mun.nome Municipio, bai.nome Bairro, fin.nome Finalidade,
		cat.nome Categoria, imov.ds_endereco Endereco, imov.ds_numeroEndereco Numero, 
		imov.ds_complemento Complemento, imov.id_dormitorio Dormitorios, 
		imov.vl_imovel Valor, imov.vl_condominio Condominio, 
		(SELECT TOP 1 img.nome FROM Imagem img WHERE img.id_imovel = imov.id) Imagem FROM Imovel imov 
		LEFT JOIN Estado est ON imov.id_estado = est.id 
		LEFT JOIN Municipio mun ON imov.id_municipio = mun.id 
		LEFT JOIN Bairro bai ON imov.id_bairro = bai.id 
		LEFT JOIN Finalidade fin ON imov.id_finalidade = fin.id 
		LEFT JOIN Categoria cat ON imov.id_categoria = cat.id 
		WHERE imov.id = @ID;
				    
  END 
GO

SET QUOTED_IDENTIFIER OFF