USE imobiliariainfinity
GO

IF EXISTS ( SELECT 1 FROM sys.objects WHERE OBJECT_ID = object_id(N'[DBO].[PRC_BUSCA_RAPIDA_IMOVEL]')
								      AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE [PRC_BUSCA_RAPIDA_IMOVEL]
END
GO								   

CREATE PROCEDURE [PRC_BUSCA_RAPIDA_IMOVEL]
(@ID_ESTADO INT, @ID_MUNICIPIO INT, @ID_BAIRRO INT, @ID_FINALIDADE INT, 
@ID_CATEGORIA INT, @ID_DORMITORIO INT, @VL_MAIOR INT, @VL_MENOR INT)
AS
  BEGIN
		DECLARE @SELECT VARCHAR(1000), @WHERE VARCHAR(1000), @CRITERIA VARCHAR(30), @ORDER VARCHAR(40)
		SET @CRITERIA = ''
		SET @WHERE = ''
		SET @SELECT = 'SELECT imov.id Id, est.cd_uf Estado, mun.nome Municipio, bai.nome Bairro, fin.nome Finalidade, '
		SET @SELECT = @SELECT +	'cat.nome Categoria, imov.ds_endereco Endereco, imov.ds_numeroEndereco Numero, ' 
		SET @SELECT = @SELECT +	'imov.ds_complemento Complemento, imov.id_dormitorio Dormitorios, '
		SET @SELECT = @SELECT +	'imov.vl_imovel Valor, imov.vl_condominio Condominio, '
		SET @SELECT = @SELECT + '(SELECT TOP 1 img.nome FROM Imagem img WHERE img.id_imovel = imov.id) Imagem FROM Imovel imov '
		SET @SELECT = @SELECT +	'LEFT JOIN Estado est ON imov.id_estado = est.id '
		SET @SELECT = @SELECT +	'LEFT JOIN Municipio mun ON imov.id_municipio = mun.id '
		SET @SELECT = @SELECT +	'LEFT JOIN Bairro bai ON imov.id_bairro = bai.id '
		SET @SELECT = @SELECT +	'LEFT JOIN Finalidade fin ON imov.id_finalidade = fin.id '
		SET @SELECT = @SELECT +	'LEFT JOIN Categoria cat ON imov.id_categoria = cat.id '

		IF @ID_ESTADO > 0
		BEGIN
			IF @CRITERIA = ''
				SET @CRITERIA = ' WHERE '
											
			SET @WHERE = @WHERE + @CRITERIA + 'imov.id_estado = ' + CAST(@ID_ESTADO AS VARCHAR(30))		
		END

		IF @ID_MUNICIPIO > 0
		BEGIN
			IF @CRITERIA = ''
				SET @CRITERIA = ' WHERE '
			ELSE
				SET @CRITERIA = ' AND '
				
			SET @WHERE = @WHERE + @CRITERIA + 'imov.id_municipio = ' + CAST(@ID_MUNICIPIO AS VARCHAR(30))
		END

		IF @ID_BAIRRO > 0
		BEGIN
			IF @CRITERIA = ''
				SET @CRITERIA = ' WHERE '
			ELSE
				SET @CRITERIA = ' AND '
				
			SET @WHERE = @WHERE + @CRITERIA + 'imov.id_bairro = ' + CAST(@ID_BAIRRO AS VARCHAR(30))
		END

		IF @ID_FINALIDADE > 0
		BEGIN
			IF @CRITERIA = ''
				SET @CRITERIA = ' WHERE '
			ELSE
				SET @CRITERIA = ' AND '
				
			SET @WHERE = @WHERE + @CRITERIA + 'imov.id_finalidade = ' + CAST(@ID_FINALIDADE AS VARCHAR(30))
		END

		IF @ID_CATEGORIA > 0
		BEGIN
			IF @CRITERIA = ''
				SET @CRITERIA = ' WHERE '
			ELSE
				SET @CRITERIA = ' AND '
				
			SET @WHERE = @WHERE + @CRITERIA + 'imov.id_categoria = ' + CAST(@ID_CATEGORIA AS VARCHAR(30))
		END

		IF @ID_DORMITORIO > 0
		BEGIN
			IF @CRITERIA = ''
				SET @CRITERIA = ' WHERE '
			ELSE
				SET @CRITERIA = ' AND '
				
			DECLARE @OPERADOR VARCHAR(3)		
			
			IF @ID_DORMITORIO = 4
				SET @OPERADOR = '>='
			ELSE
				SET @OPERADOR = '='
			
			SET @WHERE = @WHERE + @CRITERIA + 'imov.id_dormitorio ' + @OPERADOR + CAST(@ID_DORMITORIO AS VARCHAR(30))
			
		END
		
		IF @VL_MAIOR > 0
		BEGIN
			IF @CRITERIA = ''
				SET @CRITERIA = ' WHERE '
			ELSE
				SET @CRITERIA = ' AND '
				
			SET	@WHERE = @WHERE + @CRITERIA + 'imov.vl_imovel >= ' + CAST(@VL_MAIOR AS VARCHAR(30))
		END
		
		IF @VL_MENOR > 0
		BEGIN
			IF @CRITERIA = ''
				SET @CRITERIA = ' WHERE '
			ELSE
				SET @CRITERIA = ' AND '
			
			SET @WHERE = @WHERE + @CRITERIA + 'imov.vl_imovel <= ' + CAST(@VL_MENOR AS VARCHAR(30))
		END
		
		SET @WHERE = @WHERE + ' AND ic_ativo = 1'

		SET @ORDER = ' ORDER BY Valor'
		SET @SELECT = @SELECT + @WHERE + @ORDER

		EXEC(@SELECT)

			    
  END 
GO

SET QUOTED_IDENTIFIER OFF