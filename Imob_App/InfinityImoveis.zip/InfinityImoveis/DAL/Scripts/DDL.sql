USE imobiliariainfinity;
GO

CREATE TABLE Pais (
 id  SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 cd_Pais  CHAR(2) NOT NULL,
 nome  VARCHAR(50) NOT NULL
)

CREATE TABLE Estado (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 id_pais SMALLINT REFERENCES [Pais](id) NOT NULL,
 cd_UF CHAR(2) NOT NULL ,
 nome VARCHAR(45) NOT NULL
)

CREATE TABLE Municipio (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 id_estado SMALLINT REFERENCES [Estado](id) NOT NULL,
 nome VARCHAR(45) NOT NULL
)
 
CREATE TABLE Bairro (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 id_municipio SMALLINT REFERENCES [Municipio](id) NOT NULL,
 nome VARCHAR(45) NOT NULL
)
  
CREATE TABLE Categoria (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 nome VARCHAR(40) NOT NULL
) 
  
CREATE TABLE Dormitorio (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 nome SMALLINT NOT NULL,
)

CREATE TABLE Finalidade (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 nome VARCHAR(40) NOT NULL
)

CREATE TABLE EstadoImovel (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 nome VARCHAR(40) NOT NULL 
)

CREATE TABLE Proprietario (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 nome VARCHAR(70) NOT NULL,
 ds_profissao VARCHAR(30) NULL,
 cd_cpf CHAR(11) NULL,
 cd_rg CHAR(9) NULL,
 ds_email VARCHAR(50) NULL,
 nm_conjuge VARCHAR(70) NULL,
 ds_telefone1 VARCHAR(20) NULL,
 ds_tipo_telefone_1 VARCHAR(40) NULL,
 ds_telefone2 VARCHAR(20) NULL,
 ds_tipo_telefone_2 VARCHAR(40) NULL,
)

CREATE TABLE PosicaoImovel (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 ds_posicao VARCHAR(20) NOT NULL
)

CREATE TABLE Social (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 ds_item VARCHAR(40) NULL
)

CREATE TABLE Acabamento (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 ds_item VARCHAR(40) NULL
)

CREATE TABLE Intima (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 ds_item VARCHAR(40) NULL
)

CREATE TABLE Servicos (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 ds_item VARCHAR(40) NULL
)

CREATE TABLE Armarios (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 ds_item VARCHAR(40) NULL
)

CREATE TABLE Lazer (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 ds_item VARCHAR(40) NULL
)

CREATE TABLE Imovel (
 id SMALLINT NOT NULL PRIMARY KEY IDENTITY,
 id_proprietario SMALLINT REFERENCES [Proprietario](id) NOT NULL,
 id_finalidade SMALLINT REFERENCES [Finalidade](id) NOT NULL,
 id_categoria SMALLINT REFERENCES [Categoria](id) NOT NULL,
 ds_padrao VARCHAR(50) NULL,
 ds_endereco VARCHAR(60) NOT NULL,
 ds_numeroEndereco VARCHAR(10) NOT NULL,
 ds_complemento VARCHAR(20) NOT NULL,
 id_bairro SMALLINT REFERENCES [Bairro](id) NOT NULL,
 id_municipio SMALLINT REFERENCES [Municipio](id) NOT NULL,
 id_estado SMALLINT REFERENCES [Estado](id) NOT NULL,
 ds_garagem VARCHAR(30) NULL,
 ds_portaria VARCHAR(30) NULL,
 ds_situacao VARCHAR(60) NULL, 
 id_estadoImovel SMALLINT REFERENCES [EstadoImovel](id) NOT NULL,
 id_dormitorio SMALLINT REFERENCES [Dormitorio](id) NOT NULL,
 id_posicao SMALLINT REFERENCES [PosicaoImovel](id) NULL,
 ds_banheiro VARCHAR(80) NULL,
 nm_edificio VARCHAR(40) NULL,
 ic_financiamento bit NULL,
 vl_imovel DECIMAL NOT NULL,
 vl_sem_comissao DECIMAL NOT NULL,
 vl_iptu DECIMAL NULL,
 vl_condominio DECIMAL NULL,
 ic_vazio bit NULL,
 cd_registro VARCHAR(20) NULL,
 ic_documentacao bit NULL,
 ic_elevador bit NULL,
 ds_localChaves VARCHAR(40) NULL,
 vl_areaUtil DECIMAL NULL,
 vl_areaTotal DECIMAL NULL,
 ic_destaque bit NULL,
 ic_ativo bit NULL
)

CREATE TABLE Imagem (
 id SMALLINT NOT NULL PRIMARY KEY,
 id_imovel SMALLINT REFERENCES [Imovel](id) NOT NULL,
 nome VARCHAR(200) NOT NULL
)

CREATE TABLE ImovelSocial (
 id_imovel SMALLINT REFERENCES [Imovel](id) NOT NULL,
 id_social SMALLINT REFERENCES [Social](id) NOT NULL
 PRIMARY KEY(id_imovel,id_social)
)

CREATE TABLE ImovelAcabamento (
 id_imovel SMALLINT REFERENCES [Imovel](id) NOT NULL,
 id_acabamento SMALLINT REFERENCES [Acabamento](id) NOT NULL
 PRIMARY KEY(id_imovel,id_acabamento)
)

CREATE TABLE ImovelIntima (
 id_imovel SMALLINT REFERENCES [Imovel](id) NOT NULL,
 id_intima SMALLINT REFERENCES [Intima](id) NOT NULL
 PRIMARY KEY(id_imovel,id_intima)
)

CREATE TABLE ImovelServicos (
 id_imovel SMALLINT REFERENCES [Imovel](id) NOT NULL,
 id_servicos SMALLINT REFERENCES [Servicos](id) NOT NULL
 PRIMARY KEY(id_imovel,id_servicos)
)

CREATE TABLE ImovelArmarios (
 id_imovel SMALLINT REFERENCES [Imovel](id) NOT NULL,
 id_armarios SMALLINT REFERENCES [Armarios](id) NOT NULL
 PRIMARY KEY(id_imovel,id_armarios)
)

CREATE TABLE ImovelLazer (
 id_imovel SMALLINT REFERENCES [Imovel](id) NOT NULL,
 id_lazer SMALLINT REFERENCES [Lazer](id) NOT NULL
 PRIMARY KEY(id_imovel,id_lazer)
)
 
CREATE TABLE [User] (
 id_user SMALLINT PRIMARY KEY IDENTITY NOT NULL,
 ds_user VARCHAR(40) NOT NULL,
 ds_password VARCHAR(300) NOT NULL
)

CREATE TABLE Erro_log
(
	id INT PRIMARY KEY IDENTITY,
	ds_erro VARCHAR(500),
	dt_erro DATETIME,
	ds_stack VARCHAR(255),
	ds_metodo VARCHAR(100)
	
)

CREATE TABLE Slider
(
	id INT PRIMARY KEY,
	ds_path_imagem VARCHAR(255) NOT NULL,
	ds_texto1 VARCHAR(29) NOT NULL,
	ds_texto2 VARCHAR(24) NOT NULL,
	ic_ativo BIT NOT NULL
)
