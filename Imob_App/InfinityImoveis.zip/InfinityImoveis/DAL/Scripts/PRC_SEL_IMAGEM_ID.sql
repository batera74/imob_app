USE imobiliariainfinity
GO

IF EXISTS (SELECT 1 FROM sys.objects WHERE OBJECT_ID = object_id(N'[DBO].[PRC_SEL_IMAGEM_ID]')
								      AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE PRC_SEL_IMAGEM_ID
END
GO								   

CREATE PROCEDURE PRC_SEL_IMAGEM_ID
(@ID_IMAGEM INT)
AS
  BEGIN
	SELECT nome Nome FROM Imagem img WHERE id = @ID_IMAGEM
  END
 