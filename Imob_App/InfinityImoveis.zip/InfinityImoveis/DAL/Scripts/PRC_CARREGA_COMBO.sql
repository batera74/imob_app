USE imobiliariainfinity
GO

IF EXISTS ( SELECT 1 FROM sys.objects WHERE OBJECT_ID = object_id(N'[DBO].[PRC_CARREGA_COMBO]')
								      AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE [PRC_CARREGA_COMBO]
END
GO								   

CREATE PROCEDURE [PRC_CARREGA_COMBO](@TABLE VARCHAR(50), @ID INT = 0)
AS
  BEGIN		
		IF (@ID = 0)	
			EXEC ('SELECT * FROM ' + @TABLE + ' ORDER BY nome')
		ELSE IF (@ID > 0 AND @TABLE = 'Municipio')	
			EXEC ('SELECT * FROM ' + @TABLE + ' WHERE id_estado = ' + @ID + ' ORDER BY nome')
		ELSE IF (@ID > 0 AND @TABLE = 'Bairro')
			EXEC ('SELECT * FROM ' + @TABLE + ' WHERE id_municipio = ' + @ID + ' ORDER BY nome')
  END
GO

SET QUOTED_IDENTIFIER OFF