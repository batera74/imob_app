USE imobiliariainfinity
GO

IF EXISTS (SELECT 1 FROM sys.objects WHERE OBJECT_ID = object_id(N'[DBO].[PRC_INS_IMAGEM_IMOVEL]')
								      AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE PRC_INS_IMAGEM_IMOVEL
END
GO								   

CREATE PROCEDURE PRC_INS_IMAGEM_IMOVEL(@ID_IMOVEL AS INT)
AS
  BEGIN
  DECLARE @ID INT;
  SET @ID = (SELECT MAX(ID) + 1 FROM Imagem )
  
  IF @ID IS NULL
    SET @ID = 1
  
  INSERT INTO Imagem (id, id_imovel, nome) VALUES (@ID, @ID_IMOVEL, 'img' + CAST(@ID AS VARCHAR) + '.jpg')  
   SELECT MAX(ID) FROM Imagem
  END