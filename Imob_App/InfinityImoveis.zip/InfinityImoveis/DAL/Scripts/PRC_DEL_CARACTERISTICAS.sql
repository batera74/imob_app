USE imobiliariainfinity
GO

IF EXISTS ( SELECT 1 FROM sys.objects WHERE OBJECT_ID = object_id(N'[DBO].[PRC_DEL_CARACTERISTICAS]')
								      AND TYPE IN (N'P'))
BEGIN
	DROP PROCEDURE [PRC_DEL_CARACTERISTICAS]
END
GO								   

CREATE PROCEDURE [PRC_DEL_CARACTERISTICAS](@ID INT)
AS
  BEGIN
		DELETE FROM ImovelAcabamento WHERE id_imovel = @ID;		
		DELETE FROM ImovelArmarios WHERE id_imovel = @ID;		
		DELETE FROM ImovelIntima WHERE id_imovel = @ID;		
		DELETE FROM ImovelLazer WHERE id_imovel = @ID;
		DELETE FROM ImovelServicos WHERE id_imovel = @ID;		
		DELETE FROM ImovelSocial WHERE id_imovel = @ID;
  END 
GO

SET QUOTED_IDENTIFIER OFF