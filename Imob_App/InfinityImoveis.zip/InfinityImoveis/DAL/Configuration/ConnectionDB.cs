﻿using System;
using System.Configuration;

namespace DAL.Configuration
{
    public static class ConnectionDB
    {
        //fields
        private static string connString;
        private static string provName;

        //Construtor
        static ConnectionDB()
        {
            //Recebe a string de conexão e o provider do arquivo de Settings
            try
            {
                connString = ConfigurationManager.ConnectionStrings["INFINITY"].ConnectionString;
                provName = ConfigurationManager.ConnectionStrings["INFINITY"].ProviderName;
            }
            catch
            {
                throw new Exception("Erro ao criar a conexão!");
            }
        }

        //propriedades dos fields
        public static string ConnString
        {
            get { return connString; }
        }

        public static string ProvName
        {
            get { return provName; }
        }
    }
}
