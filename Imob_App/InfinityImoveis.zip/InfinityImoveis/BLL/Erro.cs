﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;
using DAL;
using System.Data;
using System.Data.Common;

namespace BLL
{
    public static class Erro
    {
        public static void LogErro(Entity.Erro _erro)
        {
            List<DbParameter> param = new List<DbParameter>();
            param.Add(DataAccess.CreateParameter("@DS_ERRO", System.Data.DbType.String, _erro.DsErro));
            param.Add(DataAccess.CreateParameter("@DT_ERRO", System.Data.DbType.DateTime, _erro.DtOcorrido));
            param.Add(DataAccess.CreateParameter("@DS_STACK", System.Data.DbType.String, _erro.Stack));
            param.Add(DataAccess.CreateParameter("@DS_METODO", System.Data.DbType.String, _erro.Metodo));

            DataAccess.executeCommand("PRC_INS_ERRO_LOG", CommandType.StoredProcedure,
                param, TypeCommand.ExecuteDataTable);
        }
    }
}
