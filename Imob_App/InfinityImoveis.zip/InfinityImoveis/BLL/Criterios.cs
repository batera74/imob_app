﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;
using System.Web.UI.WebControls;

namespace BLL
{
    public static class Criterios
    {
        public static CriteriosPesquisa SetaCriterios(DropDownList cboEstado, DropDownList cboMunicipio, DropDownList cboBairro,
                                                      DropDownList cboFinalidade, DropDownList cboCategoria, DropDownList cboDormitorio,
                                                      DropDownList cboVlMaior, DropDownList cboVlMenor)
        {
            try
            {

                CriteriosPesquisa criterios = new CriteriosPesquisa(cboEstado.SelectedIndex == 0 ? "Indiferente" : cboEstado.SelectedItem.Text,
                                         cboMunicipio.SelectedIndex == 0 ? "Indiferente" : cboMunicipio.SelectedItem.Text,
                                         cboBairro.SelectedIndex == 0 ? "Indiferente" : cboBairro.SelectedItem.Text,
                                         cboFinalidade.SelectedIndex == 0 ? "Indiferente" : cboFinalidade.SelectedItem.Text,
                                         cboCategoria.SelectedIndex == 0 ? "Indiferente" : cboCategoria.SelectedItem.Text,
                                         cboDormitorio.SelectedIndex == 0 ? "Indiferente" : cboDormitorio.SelectedItem.Text,
                                         cboVlMaior.SelectedIndex == 0 ? "Indiferente" : cboVlMaior.SelectedItem.Text,
                                         cboVlMenor.SelectedIndex == 0 ? "Indiferente" : cboVlMenor.SelectedItem.Text);

                return criterios;
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return null;
            }
        }

        public static CriteriosPesquisa SetaCriterios(DropDownList cboEstado, DropDownList cboMunicipio, DropDownList cboBairro,
                                                      DropDownList cboFinalidade, DropDownList cboCategoria, DropDownList cboDormitorio,
                                                      DropDownList cboVlMaior, DropDownList cboVlMenor, string _texto)
        {
            try
            {
                CriteriosPesquisa criterios = new CriteriosPesquisa();

                if (cboFinalidade == null)
                {
                    criterios = new CriteriosPesquisa(cboEstado.SelectedIndex == 0 ? "Indiferente" : cboEstado.SelectedItem.Text,
                                             cboMunicipio.SelectedIndex == 0 ? "Indiferente" : cboMunicipio.SelectedItem.Text,
                                             cboBairro.SelectedIndex == 0 ? "Indiferente" : cboBairro.SelectedItem.Text,
                                             _texto,
                                             cboCategoria.SelectedIndex == 0 ? "Indiferente" : cboCategoria.SelectedItem.Text,
                                             cboDormitorio.SelectedIndex == 0 ? "Indiferente" : cboDormitorio.SelectedItem.Text,
                                             cboVlMaior.SelectedIndex == 0 ? "Indiferente" : cboVlMaior.SelectedItem.Text,
                                             cboVlMenor.SelectedIndex == 0 ? "Indiferente" : cboVlMenor.SelectedItem.Text);
                }

                if (cboCategoria == null)
                {
                    criterios = new CriteriosPesquisa(cboEstado.SelectedIndex == 0 ? "Indiferente" : cboEstado.SelectedItem.Text,
                                        cboMunicipio.SelectedIndex == 0 ? "Indiferente" : cboMunicipio.SelectedItem.Text,
                                        cboBairro.SelectedIndex == 0 ? "Indiferente" : cboBairro.SelectedItem.Text,
                                        cboFinalidade.SelectedIndex == 0 ? "Indiferente" : cboFinalidade.SelectedItem.Text,
                                        _texto,
                                        cboDormitorio.SelectedIndex == 0 ? "Indiferente" : cboDormitorio.SelectedItem.Text,
                                        cboVlMaior.SelectedIndex == 0 ? "Indiferente" : cboVlMaior.SelectedItem.Text,
                                        cboVlMenor.SelectedIndex == 0 ? "Indiferente" : cboVlMenor.SelectedItem.Text);
                }

                return criterios;
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return null;
            }
        }
    }
}
