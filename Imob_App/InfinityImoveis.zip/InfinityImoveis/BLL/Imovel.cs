﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DAL;
using System.Data;

namespace BLL
{
    public static class Imovel
    {
        public static void Inserir(Entity.Imovel _imovelNovo)
        {
        }

        public static void Deletar()
        {
        }

        public static void Atualizar()
        {
        }

        public static void Selecionar()
        {
        }

        public static void DeletarCaracteristicas(int _id)
        {
            List<DbParameter> param = new List<DbParameter>();
            param.Add(DataAccess.CreateParameter("@ID", DbType.Int16, _id));

            DataAccess.executeCommand("PRC_DEL_CARACTERISTICAS", CommandType.StoredProcedure,
               param, TypeCommand.ExecuteNonQuery);
        }
    }
}
