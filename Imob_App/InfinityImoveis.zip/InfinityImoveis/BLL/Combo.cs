﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using System.Data;
using System.Data.Common;
using System.Web;
using System.Web.UI.WebControls;

namespace BLL
{
    public static class Combo
    {
        public static void CarregarCombos(DropDownList _comboBox, string _table, object _id)
        {
            try
            {
                _comboBox.Items.Clear();
                _comboBox.Items.Add(new ListItem("Carregando...", ""));

                List<DbParameter> param = new List<DbParameter>();

                _comboBox.AppendDataBoundItems = true;

                if (_id == null)
                    param.Add(DataAccess.CreateParameter("@TABLE", System.Data.DbType.String, _table));
                else
                {
                    param.Add(DataAccess.CreateParameter("@TABLE", System.Data.DbType.String, _table));
                    param.Add(DataAccess.CreateParameter("@ID", System.Data.DbType.Int32, Convert.ToInt32(_id)));
                }

                _comboBox.DataSource = (DataTable)DataAccess.executeCommand("PRC_CARREGA_COMBO", System.Data.CommandType.StoredProcedure,
                    param, TypeCommand.ExecuteDataTable);
                _comboBox.DataValueField = "id";

                if (!_comboBox.ID.Equals("cboEstado"))
                    _comboBox.DataTextField = "nome";
                else
                    _comboBox.DataTextField = "cd_uf";

                _comboBox.Items[0].Text = _table;
                _comboBox.DataBind();
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
            }

        }

        public static void CarregarCboMunicipio(DropDownList cboEstado, DropDownList cboMunicipio, DropDownList cboBairro)
        {
            try
            {
                cboMunicipio.Items.Clear();
                cboMunicipio.Items.Add(new ListItem("Município", ""));
                cboBairro.Items.Clear();
                cboBairro.Items.Add(new ListItem("Bairro", ""));

                if (cboEstado.SelectedIndex > 0)
                {                    
                    cboMunicipio.AppendDataBoundItems = true;
                    Combo.CarregarCombos(cboMunicipio, "Municipio", cboEstado.SelectedValue);
                    cboMunicipio.Enabled = true;
                }
                else
                {
                    cboMunicipio.Enabled = false;
                    cboBairro.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
            }

        }

        public static void CarregarCboBairro(DropDownList cboMunicipio, DropDownList cboBairro)
        {
            try
            {
                cboBairro.Items.Clear();
                cboBairro.Items.Add(new ListItem("Bairro", ""));
                cboBairro.AppendDataBoundItems = true;
                if (cboMunicipio.SelectedIndex > 0)
                {
                    Combo.CarregarCombos(cboBairro, "Bairro", cboMunicipio.SelectedValue);
                    cboBairro.Enabled = true;
                }
                else
                {
                    cboBairro.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
            }
        }
    }
}
