﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Net;

namespace BLL
{
    public static class Mail
    {
        public static string EnviarEmail(string _assunto, string _msg, string _de, string _deNome)
        {
            MailAddress de = new MailAddress(_de, _deNome);
            MailAddress para = new MailAddress("contato@imobiliariainfinity.com.br", "Contato Site");

            SmtpClient sc = new SmtpClient("smtp.gmail.com");
            sc.Credentials = new System.Net.NetworkCredential("infinityimob@gmail.com", "infinity2010");
            sc.EnableSsl = true;
            MailMessage msg = new MailMessage(de, para);
            //msg.Attachments.Add(new Attachment("Teste.txt"));
            msg.Subject = "Contato de " + _deNome + " pelo Site: " + _assunto;
            msg.Body = _msg;
            msg.IsBodyHtml = true;

            try
            {
                sc.Send(msg);
                return "Email enviado com sucesso!";
            }

            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return "Ocorreu um erro no envio da mensagem!";
            }
        }
    }
}
