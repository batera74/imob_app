﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DAL;
using Entity;
using System.Data.Common;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;
using System.Configuration;

namespace BLL
{
    public static class Imagem
    {
        public static DataTable CarregarImagens(int _id_imovel)
        {
            try
            {
                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@ID_IMOVEL", DbType.Int32, _id_imovel));

                return (DataTable)DataAccess.executeCommand("PRC_SEL_IMAGEM_IMOVEL", CommandType.StoredProcedure,
                    param, TypeCommand.ExecuteDataTable);
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return null;
            }
        }

        public static int InserirImagem(int _id_imovel)
        {
            try
            {
                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@ID_IMOVEL", DbType.String, _id_imovel));

                DataTable dt = (DataTable)DataAccess.executeCommand("PRC_INS_IMAGEM_IMOVEL", CommandType.StoredProcedure,
                    param, TypeCommand.ExecuteDataTable);

                return Convert.ToInt32(dt.Rows[0][0]);
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return 0;
            }
        }

        public static void DeletarImagem(int _id, int _id_imovel)
        {
            try
            {
                if (_id == 0)
                {
                    DataTable imgImovel = CarregarImagens(_id_imovel);

                    try
                    {
                        for (int i = 0; i < imgImovel.Rows.Count; i++)
                        {
                            File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + imgImovel.Rows[i]["Imagem"].ToString()));
                            File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + "big/" + imgImovel.Rows[i]["Imagem"].ToString()));
                            File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + "mini/" + imgImovel.Rows[i]["Imagem"].ToString()));
                            File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + "lightbox/" + imgImovel.Rows[i]["Imagem"].ToString()));
                        }
                    }
                    catch(Exception ex)
                    {
                        throw ex;
                    }                    
                }
                else
                {
                    DeletarImagemDiretorio(_id);
                }
                DeletarImagemBanco(_id, _id_imovel);
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
            }
        }

        public static void DeletarImagemBanco(int _id, int _id_imovel)
        {
            try
            {
                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@ID_IMAGEM", DbType.Int16, _id));
                param.Add(DataAccess.CreateParameter("@ID_IMOVEL", DbType.Int16, _id_imovel));

                DataAccess.executeCommand("PRC_DEL_IMAGEM_IMOVEL", CommandType.StoredProcedure,
                   param, TypeCommand.ExecuteNonQuery);
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
            }
        }

        public static void DeletarImagemDiretorio(int _id)
        {
            try
            {
                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@ID_IMAGEM", DbType.Int16, _id));

                DataTable dt = (DataTable)DataAccess.executeCommand("PRC_SEL_IMAGEM_ID", CommandType.StoredProcedure,
                   param, TypeCommand.ExecuteDataTable);

                File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + dt.Rows[0][0].ToString()));
                File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + "big/" + dt.Rows[0][0].ToString()));
                File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + "mini/" + dt.Rows[0][0].ToString()));
                File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + "lightbox/" + dt.Rows[0][0].ToString()));
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
            }
        }

        public static void Resize(string _srcPath, string _destPath, int _nWidth, int _nHeight, bool _proporcional)
        {
            try
            {
                string temp;

                Image img = Image.FromFile(_srcPath);
                int oWidth = img.Width;
                int oHeight = img.Height;

                if (_proporcional)
                {
                    if (oWidth > _nWidth || oHeight > _nHeight)
                    {
                        if (oWidth > oHeight)
                            _nHeight = (oHeight * _nWidth) / oWidth;
                        else
                            _nWidth = (oWidth * _nHeight) / oHeight;
                    }
                }

                Image imgThumb = img.GetThumbnailImage(_nWidth, _nHeight, null, new System.IntPtr(0));

                if (_srcPath == _destPath)
                {
                    temp = _destPath + ".tmp";
                    imgThumb.Save(temp, ImageFormat.Jpeg);
                    img.Dispose();
                    imgThumb.Dispose();
                    File.Delete(_srcPath);
                    File.Copy(temp, _srcPath);
                    File.Delete(temp);
                }
                else
                {
                    imgThumb.Save(_destPath, ImageFormat.Jpeg);
                    imgThumb.Dispose();
                    img.Dispose();
                }
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
            }
        }

        public static string UploadImagem(System.Web.UI.HtmlControls.HtmlInputFile _file, int _id)
        {
            try
            {
                if (_file.PostedFile != null)
                {
                    string StrFileName = _file.PostedFile.FileName.Substring(_file.PostedFile.FileName.LastIndexOf("\\") + 1);
                    string StrFileType = _file.PostedFile.ContentType;

                    int IntFileSize = _file.PostedFile.ContentLength;

                    if (IntFileSize <= 0)
                        return "A tentativa de upload do arquivo " + StrFileName + " falhou!";
                    else
                    {
                        //Imagem padrão
                        string src = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"]) + "img" + _id + ".jpg";
                        _file.PostedFile.SaveAs(src);

                        File.Copy(src,HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + "lightbox/" + "img" + _id + ".jpg"));

                        //Big
                        Resize(src, HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + "big/") + "img" + _id + ".jpg", 245, 209, false);                        
                        //Normal
                        Resize(src, src, 159, 136, false);
                        //Mini
                        Resize(src, HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathImagem"] + "mini/") + "img" + _id + ".jpg", 74, 63, false);
                        

                        //Informa na tela que o arquivo foi gravado e mostra detalhes sobre o arquivo, nome, tipo de arquivo e o tamanho em bytes.
                        return "O seu arquivo " + StrFileName + " do tipo " + StrFileType + " e tamanho " + IntFileSize.ToString() + " bytes foi gravado com sucesso!";
                    }
                }
                return "Arquivo Vazio";
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return "Erro!";
            }
        }
    }
}
