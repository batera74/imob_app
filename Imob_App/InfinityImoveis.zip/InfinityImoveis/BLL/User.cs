﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using Entity;
using System.Data.Common;
using System.Data;

namespace BLL
{
    public static class User
    {
        public static Boolean ValidarUsuario(Entity.User user)
        {
            try
            {
                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@USER", DbType.String, user.Username));
                param.Add(DataAccess.CreateParameter("@PASSWORD", DbType.String, user.Password));

                DbDataReader reader = (DbDataReader)DataAccess.executeCommand("PRC_SEL_USER", CommandType.StoredProcedure,
                    param, TypeCommand.ExecuteReader);

                return reader.HasRows;
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return false;
            }
        }
    }
}
