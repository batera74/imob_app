﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;

namespace BLL
{
    public static class LabelPesquisa
    {
        public static string FiltrosPesquisa(CriteriosPesquisa criterios)
        {
            try
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("Filtros-> Estado: ");
                sb.Append(criterios.Estado);
                sb.Append(" | Município: ");
                sb.Append(criterios.Municipio);
                sb.Append(" | Bairro: ");
                sb.Append(criterios.Bairro);
                sb.Append(" | Finalidade: ");
                sb.Append(criterios.Finalidade);
                sb.Append(" | Categoria: ");
                sb.Append(criterios.Categoria);
                sb.Append(" | Dormitórios: ");
                sb.Append(criterios.Dormitorio);
                sb.Append(" | Valor menor que: ");
                sb.Append(criterios.ValorMaior);
                sb.Append(" | Valor maior que: ");
                sb.Append(criterios.ValorMenor);                
                return sb.ToString();
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return null;
            }
        }
    }
}
