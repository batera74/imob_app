﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;
using Entity;
using System.Data;
using System.Data.Common;
using System.Web;
using System.Data.SqlClient;
using System.IO;


namespace BLL
{
    public static class Pesquisa
    {
        public static DataTable BuscaRapida(ImovelBusca _imovelBusca)
        {
            List<DbParameter> param = new List<DbParameter>();

            param.Add(DataAccess.CreateParameter("@ID_ESTADO", DbType.Int32, _imovelBusca.Estado));
            param.Add(DataAccess.CreateParameter("@ID_MUNICIPIO", DbType.Int32, _imovelBusca.Municipio));
            param.Add(DataAccess.CreateParameter("@ID_BAIRRO", DbType.Int32, _imovelBusca.Bairro));
            param.Add(DataAccess.CreateParameter("@ID_FINALIDADE", DbType.Int32, _imovelBusca.Finalidade));
            param.Add(DataAccess.CreateParameter("@ID_CATEGORIA", DbType.Int32, _imovelBusca.Categoria));
            param.Add(DataAccess.CreateParameter("@ID_DORMITORIO", DbType.Int32, _imovelBusca.Dormitorio));
            param.Add(DataAccess.CreateParameter("@VL_MAIOR", DbType.Int32, _imovelBusca.VlMaior));
            param.Add(DataAccess.CreateParameter("@VL_MENOR", DbType.Int32, _imovelBusca.VlMenor));

            return (DataTable)DataAccess.executeCommand("PRC_BUSCA_RAPIDA_IMOVEL", CommandType.StoredProcedure,
                param, TypeCommand.ExecuteDataTable);
        }

        public static DataTable BuscaRapida(int id)
        {
            List<DbParameter> param = new List<DbParameter>();
            param.Add(DataAccess.CreateParameter("@ID", DbType.Int32, id));

            return (DataTable)DataAccess.executeCommand("PRC_BUSCA_RAPIDA_IMOVEL_ID", CommandType.StoredProcedure,
                param, TypeCommand.ExecuteDataTable);
        }

        public static DataTable BuscaDestaques()
        {
            return (DataTable)DataAccess.executeCommand("PRC_BUSCA_DESTAQUE", CommandType.StoredProcedure, null, TypeCommand.ExecuteDataTable);
        }

        public static int SelecionarCategoria(string _categoria)
        {
            List<DbParameter> param = new List<DbParameter>();
            param.Add(DataAccess.CreateParameter("@NM_CATEGORIA", DbType.String, _categoria));

            DataTable dt = (DataTable)DataAccess.executeCommand("PRC_SEL_CATEGORIA", CommandType.StoredProcedure,
                param, TypeCommand.ExecuteDataTable);

            return (dt.Rows.Count > 0 ? Convert.ToInt16(dt.Rows[0][0]) : 0);
        }

        public static int SelecionarFinalidade(string _finalidade)
        {
            List<DbParameter> param = new List<DbParameter>();
            param.Add(DataAccess.CreateParameter("@NM_FINALIDADE", DbType.String, _finalidade));

            DataTable dt = (DataTable)DataAccess.executeCommand("PRC_SEL_FINALIDADE", CommandType.StoredProcedure,
                param, TypeCommand.ExecuteDataTable);

            return (dt.Rows.Count > 0 ? Convert.ToInt16(dt.Rows[0][0]) : 0);
        }

        public static DataTable SelecionarImagemImovel(int _id_imovel)
        {
            List<DbParameter> param = new List<DbParameter>();
            param.Add(DataAccess.CreateParameter("@ID_IMOVEL", DbType.Int32, _id_imovel));

            return (DataTable)DataAccess.executeCommand("PRC_SEL_IMAGEM_IMOVEL", CommandType.StoredProcedure, param, TypeCommand.ExecuteDataTable);
        }

        public static DataSet SelecionarImovel(int _id_imovel)
        {
            List<DbParameter> param = new List<DbParameter>();
            param.Add(DataAccess.CreateParameter("@ID_IMOVEL", DbType.Int32, _id_imovel));
            DbDataReader dr = (DbDataReader)DataAccess.executeCommand("PRC_SEL_IMOVEL", CommandType.StoredProcedure, param, TypeCommand.ExecuteReader);
            DataSet ds = new DataSet();
            dr.Read();
            ds.ReadXml(new MemoryStream(Encoding.Unicode.GetBytes("<?xml version=\"1.0\"?>" + dr[0].ToString())));
            return ds;
        }
    }
}
