﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DAL;
using System.Data;
using System.Web;
using System.IO;
using System.Configuration;

namespace BLL
{
    public class Slider
    {
        public static DataTable Salvar(string _txt1, string _txt2, bool _ativo)
        {
            try
            {
                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@DS_TEXTO1", DbType.String, _txt1));
                param.Add(DataAccess.CreateParameter("@DS_TEXTO2", DbType.String, _txt1));
                param.Add(DataAccess.CreateParameter("@IC_ATIVO", DbType.Boolean, _ativo));

                return (DataTable)DataAccess.executeCommand("PRC_INS_SLIDER", CommandType.StoredProcedure,
                   param, TypeCommand.ExecuteDataTable);
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return null;
            }
        }

        public static void Salvar(string _slider, int _id)
        {
            string sourceFile = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathSlider"] + _slider + ".jpg");
            string destinationFile = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathSlider"] + "img" + _id + ".jpg");
            System.IO.File.Move(sourceFile, destinationFile);
        }

        public static string UploadSlider(System.Web.UI.HtmlControls.HtmlInputFile _file)
        {
            try
            {
                string src = "";

                if (_file.PostedFile != null)
                {
                    string StrFileName = _file.PostedFile.FileName.Substring(_file.PostedFile.FileName.LastIndexOf("\\") + 1);
                    string StrFileType = _file.PostedFile.ContentType;

                    int IntFileSize = _file.PostedFile.ContentLength;

                    if (IntFileSize <= 0)
                        return "A tentativa de upload do arquivo " + StrFileName + " falhou!";
                    else
                    {
                        string srcData = DateTime.Now.ToString("yyyyMMddHHmmss");
                        //Imagem padrão
                        src = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathSlider"]) + srcData + ".jpg";
                        _file.PostedFile.SaveAs(src);

                        BLL.Imagem.Resize(src, src, 940, 300, false);
                        //Informa na tela que o arquivo foi gravado e mostra detalhes sobre o arquivo, nome, tipo de arquivo e o tamanho em bytes.
                        return srcData;

                    }
                }                
                return "Arquivo Vazio";
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return "Erro!";
            }
        }

        public static DataTable Carregar(bool _ativo)
        {
            try
            {
                if (_ativo)
                {
                    return (DataTable)DataAccess.executeCommand("PRC_SEL_SLIDER_ATIVO", CommandType.StoredProcedure,
                        null, TypeCommand.ExecuteDataTable);
                }
                else
                {

                    return (DataTable)DataAccess.executeCommand("PRC_SEL_SLIDER", CommandType.StoredProcedure,
                        null, TypeCommand.ExecuteDataTable);
                }
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                return null;
            }
        }

        public static void Deletar(int _id)
        {
            try
            {
                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@ID_SLIDE", DbType.Int16, _id));

                DataAccess.executeCommand("PRC_DEL_SLIDER", CommandType.StoredProcedure,
                   param, TypeCommand.ExecuteNonQuery);

                File.Delete(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["PathSlider"] + "/img" + _id + ".jpg"));
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
            }
        }

        public static void Salvar(int _id, string _texto1, string _texto2, bool _ativo)
        {
            try
            {
                List<DbParameter> param = new List<DbParameter>();
                param.Add(DataAccess.CreateParameter("@ID_SLIDER", DbType.Int16, _id));
                param.Add(DataAccess.CreateParameter("@DS_TEXTO1", DbType.String, _texto1));
                param.Add(DataAccess.CreateParameter("@DS_TEXTO2", DbType.String, _texto2));
                param.Add(DataAccess.CreateParameter("@IC_ATIVO", DbType.Boolean, _ativo));

                DataAccess.executeCommand("PRC_UPD_SLIDER", CommandType.StoredProcedure,
                   param, TypeCommand.ExecuteNonQuery);
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
            }
        }
    }
}

