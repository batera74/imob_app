Cufon.replace('.sf-menu li a.item', { fontFamily: 'PT Sans Narrow', hover:true });
Cufon.replace('.sf-menu li li', { fontFamily: 'PT Sans Narrow 400', hover:true });
Cufon.replace('h2, h3', { fontFamily: 'Ubuntu', hover:true });
Cufon.replace('.link-1, h4, .phone', { fontFamily: 'Ubuntu_400', hover:true });
