﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BLL;
using System.Data;
using System.Text;

namespace Layout
{
    public partial class buscarImovel : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                ImovelBusca imovel = (ImovelBusca)Session["imovBusca"];
                DataTable dt = new DataTable();

                if (!IsPostBack)
                {
                    if (imovel != null)
                    {
                        Session["Pesquisa"] = Pesquisa.BuscaRapida(imovel);
                        dt = (DataTable)Session["Pesquisa"];
                    }

                    if (Session["imovCriterios"] != null)
                    {
                        lblFiltro.Text = LabelPesquisa.FiltrosPesquisa((CriteriosPesquisa)Session["imovCriterios"]);
                    }
                    else
                        lblFiltro.Text = "Não foram estipulados critérios para a pesquisa!";
                }
                else
                {
                    dt = (DataTable)Session["Pesquisa"];
                }

                resultImoveis.DataTableSource = dt;
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                resultImoveis.DataTableSource = null;
                Response.Redirect("/erro/erro.aspx");
            }
        }
    }
}