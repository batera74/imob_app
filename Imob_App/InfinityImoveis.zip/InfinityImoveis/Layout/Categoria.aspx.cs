﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using Entity;
using System.Text;
using System.Data;

namespace Layout
{
    public partial class Categoria : BasePage
    {
        private static string categoria_str;
        int categoria;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["Categoria"] != null)
            {
                categoria_str = Request.QueryString["Categoria"];
                lblTitulo.Text = categoria_str;
                categoria = Pesquisa.SelecionarCategoria(categoria_str);
            }
            else
                categoria = 0;

            ImovelBusca imovel;

            if (!IsPostBack)
            {
                Combo.CarregarCombos(cboFinalidade, "Finalidade", null);
                Combo.CarregarCombos(cboDormitorio, "Dormitorio", null);
                cboEstado.AppendDataBoundItems = true;
                Combo.CarregarCombos(cboEstado, "Estado", null);
                if (Session["criterios"] != null)
                {
                    lblFiltro.Text = LabelPesquisa.FiltrosPesquisa((CriteriosPesquisa)Session["criterios"]);
                    Session["criterios"] = null;
                }
                else
                    lblFiltro.Text = LabelPesquisa.FiltrosPesquisa(
                                     Criterios.SetaCriterios(cboEstado, cboMunicipio, cboBairro, cboFinalidade, null, cboDormitorio, cboVlMaior, cboVlMenor, categoria_str));
            }

            if (Session["imov" + categoria_str] != null)
            {
                imovel = (ImovelBusca)Session["imov" + categoria_str];
                Session.Remove("imov" + categoria_str);
            }
            else
                imovel = new ImovelBusca(0, 0, 0, 0, categoria, 0, 0, 0, 0);

            DataTable dt = Pesquisa.BuscaRapida(imovel);

            resultImoveis.DataTableSource = dt;
        }


        protected void cboEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Combo.CarregarCboMunicipio(cboEstado, cboMunicipio, cboBairro);
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                Response.Redirect("/erro/erro.aspx");
            }
        }

        protected void cboMunicipio_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Combo.CarregarCboBairro(cboMunicipio, cboBairro);
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                Response.Redirect("/erro/erro.aspx");
            }
        }

        protected void btnPesquisar_Click(object sender, EventArgs e)
        {
            ImovelBusca imovel = new ImovelBusca(cboEstado.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboEstado.SelectedValue),
                                                cboMunicipio.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboMunicipio.SelectedValue),
                                                cboBairro.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboBairro.SelectedValue),
                                                cboFinalidade.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboFinalidade.SelectedValue),
                                                categoria,
                                                cboDormitorio.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboDormitorio.SelectedValue),
                                                cboVlMaior.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboVlMaior.SelectedValue),
                                                cboVlMenor.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboVlMenor.SelectedValue),
                                                0);

            Session["imov" + categoria_str] = imovel;
            Session["criterios"] = Criterios.SetaCriterios(cboEstado, cboMunicipio, cboBairro, cboFinalidade, null, cboDormitorio, cboVlMaior, cboVlMenor, categoria_str);
            
            Response.Redirect("Categoria.aspx?Categoria=" + categoria_str);
          
        }
    }
}