﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BLL;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data;

namespace Layout.controls
{
    public partial class CustomRepeater : System.Web.UI.UserControl
    {
        int pagina;

        public int QtColunas { get; set; }
        public int QtRegistros { get; set; }
        public DataTable Source { get; set; }

        protected int counter = 0;
        protected int columnCount; 
        protected PagedDataSource pgds = new PagedDataSource();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ViewState["pagina"] = 0;
                FillDados();

                if (QtRegistros == 0)
                    QtRegistros = 6;
                if (QtColunas == 0)
                    QtColunas = 3;
            }
        }
        private void FillDados()
        {
            pagina = Convert.ToInt32(ViewState["pagina"]);

            //Seta a fonte de dados do objeto de paginação como a nossa lista de objetos
            pgds.DataSource = (Source as IListSource).GetList();

            //Permite a paginação do objeto
            pgds.AllowPaging = true;

            //Seta a pagina atual do objeto como sendo nosso ViewState de pagina.
            pgds.CurrentPageIndex = pagina;

            //Seta a quantidade de registros por página
            pgds.PageSize = QtRegistros;

            //Seta a visibilidade do botão proximo e anterior de acordo com a primeira ou ultima pagina
            btnAnt.Visible = pgds.IsFirstPage ? false : true;
            btnProx.Visible = !pgds.IsLastPage;

            //Seta a fonte de dados do repeater como o nosso objeto de paginação.
            rpt1.DataSource = pgds;
            rpt1.ItemDataBound += new RepeaterItemEventHandler(Repeater1_ItemDataBound);
            rpt1.DataBind();

            ViewState["pagina"] = pagina;
        }
        protected void Proximo(object sender, EventArgs e)
        {
            // Vai para a próxima página        
            pagina = Convert.ToInt16(ViewState["pagina"]);
            pagina++;
            ViewState["pagina"] = pagina;
            FillDados();
        }
        protected void Anterior(object sender, EventArgs e)
        {
            pagina = Convert.ToInt32(ViewState["pagina"]);
            pagina--;
            ViewState["pagina"] = pagina;
            FillDados();
        }

        private void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            columnCount = QtColunas;
            if (e.Item.ItemType == ListItemType.Separator)
                if ((++counter % columnCount) != 0)
                    e.Item.Visible = false;
        }
    }
}