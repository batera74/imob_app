﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using Entity;

namespace Layout
{
    public partial class Layout : System.Web.UI.MasterPage
    {
        public bool DeuPau = false;
        public bool comID = false;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Combo.CarregarCombos(cboFinalidade, "Finalidade", null);
                Combo.CarregarCombos(cboCategoria, "Categoria", null);
                Combo.CarregarCombos(cboDormitorio, "Dormitorio", null);
                cboEstado.AppendDataBoundItems = true;
                Combo.CarregarCombos(cboEstado, "Estado", null);
            }
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            int id = 0;
            bool erro = false;

            try
            {
                if (!txtID.Text.Equals("ID de Referência"))
                    id = Convert.ToInt32(txtID.Text);
            }
            catch (Exception ex)
            {
                txtID.Text = "Digite apenas números!";
                HabilitarControles();
                erro = true;
            }

            if (id == 0)
            {
                ImovelBusca imovel = new ImovelBusca(cboEstado.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboEstado.SelectedValue),
                                     cboMunicipio.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboMunicipio.SelectedValue),
                                     cboBairro.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboBairro.SelectedValue),
                                     cboFinalidade.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboFinalidade.SelectedValue),
                                     cboCategoria.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboCategoria.SelectedValue),
                                     cboDormitorio.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboDormitorio.SelectedValue),
                                     cboVlMaior.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboVlMaior.SelectedValue),
                                     cboVlMenor.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboVlMenor.SelectedValue),
                                     comID ? id : 0);

                Session["imovBusca"] = imovel;
                CriteriosPesquisa criterios = Criterios.SetaCriterios(cboEstado, cboMunicipio, cboBairro, cboFinalidade, cboCategoria, cboDormitorio, cboVlMaior, cboVlMenor);
                Session["imovCriterios"] = criterios;

                if (!erro)
                    Response.Redirect("buscarImovel.aspx");
            }
            else
            {
                CriteriosPesquisa criterios = Criterios.SetaCriterios(cboEstado, cboMunicipio, cboBairro, cboFinalidade, cboCategoria, cboDormitorio, cboVlMaior, cboVlMenor);
                Session["imovCriterios"] = criterios;

                if (!erro)
                    Response.Redirect("buscarImovel2.aspx?id_imovel=" + id.ToString());
            }
        }

        protected void cboEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            Combo.CarregarCboMunicipio(cboEstado, cboMunicipio, cboBairro);
        }

        protected void cboMunicipio_SelectedIndexChanged(object sender, EventArgs e)
        {
            Combo.CarregarCboBairro(cboMunicipio, cboBairro);
        }

        protected void txtID_TextChanged(object sender, EventArgs e)
        {
            HabilitarControles();
        }

        protected void HabilitarControles()
        {
            if (!txtID.Text.Equals("ID de Referência") && !txtID.Text.Equals("Digite apenas números!") && txtID.Text.Length > 0)
            {
                comID = true;
                cboEstado.Enabled = false;
                cboMunicipio.Enabled = false;
                cboBairro.Enabled = false;
                cboDormitorio.Enabled = false;
                cboCategoria.Enabled = false;
                cboFinalidade.Enabled = false;
                cboVlMaior.Enabled = false;
                cboVlMenor.Enabled = false;
            }
            else
            {
                comID = false;
                cboEstado.Enabled = true;
                cboMunicipio.Enabled = true;
                cboBairro.Enabled = true;
                cboDormitorio.Enabled = true;
                cboCategoria.Enabled = true;
                cboFinalidade.Enabled = true;
                cboVlMaior.Enabled = true;
                cboVlMenor.Enabled = true;
            }
        }
    }
}