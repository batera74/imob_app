﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using Entity;
using System.Text;
using System.Data;

namespace Layout
{
    public partial class Finalidade : System.Web.UI.Page
    {
        private static string finalidade_str;
        int finalidade;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["Finalidade"] != null)
            {
                finalidade_str = Request.QueryString["Finalidade"];
                lblTitulo.Text = finalidade_str;
                finalidade = Pesquisa.SelecionarFinalidade(finalidade_str);
            }
            else
                finalidade = 0;

            ImovelBusca imovel;

            if (!IsPostBack)
            {
                if (finalidade == 0)
                    Response.Redirect("erro/erro.aspx");

                Combo.CarregarCombos(cboCategoria, "Categoria", null);
                Combo.CarregarCombos(cboDormitorio, "Dormitorio", null);
                cboEstado.AppendDataBoundItems = true;
                Combo.CarregarCombos(cboEstado, "Estado", null);
                if (Session["criterios"] != null)
                {
                    lblFiltro.Text = LabelPesquisa.FiltrosPesquisa((CriteriosPesquisa)Session["criterios"]);
                    Session["criterios"] = null;
                }
                else
                    lblFiltro.Text = LabelPesquisa.FiltrosPesquisa(
                                     Criterios.SetaCriterios(cboEstado, cboMunicipio, cboBairro, null, cboCategoria, cboDormitorio, cboVlMaior, cboVlMenor, finalidade_str));
            }

            if (Session["imov" + finalidade_str] != null)
            {
                imovel = (ImovelBusca)Session["imov" + finalidade_str];
                Session.Remove("imov" + finalidade_str);
            }
            else
                imovel = new ImovelBusca(0, 0, 0, finalidade, 0, 0, 0, 0, 0);

            DataTable dt = Pesquisa.BuscaRapida(imovel);
            resultImoveis.DataTableSource = dt;
        }

        protected void cboEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            Combo.CarregarCboMunicipio(cboEstado, cboMunicipio, cboBairro);
        }

        protected void cboMunicipio_SelectedIndexChanged(object sender, EventArgs e)
        {
            Combo.CarregarCboBairro(cboMunicipio, cboBairro);
        }

        protected void btnPesquisar_Click(object sender, EventArgs e)
        {
            ImovelBusca imovel = new ImovelBusca(cboEstado.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboEstado.SelectedValue),
                                                cboMunicipio.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboMunicipio.SelectedValue),
                                                cboBairro.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboBairro.SelectedValue),
                                                cboCategoria.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboCategoria.SelectedValue),
                                                finalidade,
                                                cboDormitorio.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboDormitorio.SelectedValue),
                                                cboVlMaior.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboVlMaior.SelectedValue),
                                                cboVlMenor.SelectedIndex == 0 ? 0 : Convert.ToInt32(cboVlMenor.SelectedValue),
                                                0);

            Session["imov" + finalidade_str] = imovel;
            Session["criterios"] = Criterios.SetaCriterios(cboEstado, cboMunicipio, cboBairro, cboCategoria, null, cboDormitorio, cboVlMaior, cboVlMenor, finalidade_str);

            Response.Redirect("Finalidade.aspx?Finalidade=" + finalidade_str);
        }
    }
}