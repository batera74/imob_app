﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entity;
using BLL;
using System.Data;
using System.Text;

namespace Layout
{
    public partial class buscarImovel2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                int id_imovel = 0;

                try
                {
                    id_imovel = Convert.ToInt32(Request.QueryString["id_imovel"]);
                }
                catch (Exception ex)
                {

                }


                DataTable dt = new DataTable();

                if (!IsPostBack)
                {
                    if (id_imovel > 0)
                    {
                       dt = Pesquisa.BuscaRapida(id_imovel);
                       Session["Pesquisa"] = dt;
                    }

                    if(id_imovel > 0)
                        lblFiltro.Text = "Pesquisa pelo ID:" + id_imovel;
                    else if (Session["imovCriterios"] != null)
                        lblFiltro.Text = LabelPesquisa.FiltrosPesquisa((CriteriosPesquisa)Session["imovCriterios"]);                        
                    else
                        lblFiltro.Text = "Não foram estipulados critérios para a pesquisa!";                            
                }
                else
                {
                    dt = (DataTable)Session["Pesquisa"];
                }

                resultImoveis.DataTableSource = dt;
            }
            catch (Exception ex)
            {
                Entity.Erro exc = new Entity.Erro(DateTime.Now, ex.Message, ex.StackTrace.ToString(), ex.TargetSite.ToString());
                BLL.Erro.LogErro(exc);
                resultImoveis.DataTableSource = null;
                Response.Redirect("/erro/erro.aspx");
            }
        }
    }
}