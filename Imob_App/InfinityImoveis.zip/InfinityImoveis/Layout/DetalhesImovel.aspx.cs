﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using Entity;
using System.Data;
using System.Data.SqlClient;

namespace Layout
{
    public partial class DetalhesImovel : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int id_imovel = Request.QueryString["Imovel"] != null ? Convert.ToInt16(Request.QueryString["Imovel"]) : 0;
                CarregarImagensImovel(id_imovel);
                CarregarDadosImovel(id_imovel);
            }
            else
            {
                //imgBig.ImageUrl = Session["imgBigUrl"].ToString();
            }
        }

        protected void Imagem_Click(object sender, ImageClickEventArgs e)
        {
            //ImageButton imgbt = (ImageButton)sender;
            //string url = imgbt.ImageUrl;
            //url = url.Replace("mini", "big");
            //url = url.Substring(url.LastIndexOf("/") + 1);
            //DataTable dt = new DataTable();
            //DataRow dr = dt.NewRow();
            //dt.Columns.Add("url");
            //dr["url"] = url;
            //dt.Rows.Add(dr);

            //dtBig.DataSource = dt;
            //dtBig.DataBind();

        }

        private void CarregarDadosImovel(int _id_imovel)
        {
            DataSet ds = Pesquisa.SelecionarImovel(_id_imovel);
            CarregarCarateristicas(ds.Tables["Imovel"]);
            CarregarAcabamento(ds.Tables["Acabamento"]);
            CarregarArmarios(ds.Tables["Armarios"]);
            CarregarIntima(ds.Tables["Intima"]);
            CarregarLazer(ds.Tables["Lazer"]);
            CarregarServicos(ds.Tables["Servicos"]);
            CarregarSocial(ds.Tables["Social"]);

        }

        private void CarregarCarateristicas(DataTable _dtImovel)
        {
            ImovelDetalhe imov = new ImovelDetalhe(_dtImovel);
            lblImovel.Text = imov.Categoria;
            //lblEndereco.Text = imov.Endereco;
            lblCidade.Text = imov.Cidade;
            lblValor.Text = lblValor.Text + imov.Valor;
            lblCondominio.Text = lblCondominio.Text + imov.ValorCondominio;
            lblIPTU.Text = lblIPTU.Text + imov.ValorIPTU;
            lblID.Text = lblID.Text + imov.Id.ToString();
            lblBanheiro.Text = lblBanheiro.Text + imov.Banheiros;
            lblGaragem.Text = lblGaragem.Text + imov.Garagem;
            lblPortaria.Text = lblPortaria.Text + imov.Portaria;
            lblElevador.Text = lblElevador.Text + imov.Elevador;
            lblVazio.Text = lblVazio.Text + imov.Vazio;

        }

        private void CarregarImagensImovel(int _id_imovel)
        {
            DataTable dt = Pesquisa.SelecionarImagemImovel(_id_imovel);
            dtlMini.DataSource = dt;

            DataTable dt2 = new DataTable();
            dt2.Columns.Add("url");            
            DataRow dr = dt2.NewRow();

            if (dt.Rows.Count > 0)
                dr["url"] = dt.Rows[0][1];
            else
                dr["url"] = "sem_imagem.jpg";
            
            dt2.Rows.Add(dr);

            //dtBig.DataSource = dt2;
            //dtBig.DataBind();

            dtlMini.DataBind();
        }

        private void CarregarAcabamento(DataTable _dtAcabamento)
        {
            try
            {
                CarregarDataList(dtAcabamento, _dtAcabamento);
            }
            catch
            {
                CarregarDataList(dtAcabamento, null);
            }
        }

        private void CarregarArmarios(DataTable _dtArmarios)
        {
            try
            {
                CarregarDataList(dtArmarios, _dtArmarios);
            }
            catch
            {
                CarregarDataList(dtArmarios, null);
            }
        }

        private void CarregarIntima(DataTable _dtIntima)
        {
            try
            {
                CarregarDataList(dtIntima, _dtIntima);
            }
            catch
            {
                CarregarDataList(dtIntima, null);
            }
        }

        private void CarregarLazer(DataTable _dtLazer)
        {
            try
            {
                CarregarDataList(dtLazer, _dtLazer);
            }
            catch
            {
                CarregarDataList(dtLazer, null);
            }
        }

        private void CarregarServicos(DataTable _dtServicos)
        {
            try
            {
                CarregarDataList(dtServicos, _dtServicos);
            }
            catch
            {
                CarregarDataList(dtServicos, null);
            }
        }

        private void CarregarSocial(DataTable _dtSocial)
        {
            try
            {
                CarregarDataList(dtSocial, _dtSocial);
            }
            catch
            {
                CarregarDataList(dtSocial, null);
            }
        }

        private string PossuiCaracteristica(string _caracteristica)
        {
            try
            {
                return Convert.ToInt16(_caracteristica) > 0 ? "Sim" : "Não";
            }
            catch
            {
                return "Não";
            }
        }

        public void CarregarDataList(DataList _dt, DataTable _dt_src)
        {
            if (_dt_src == null)
            {
                _dt_src = new DataTable();
                DataRow dr = _dt_src.NewRow();
                dr.Table.Columns.Add("ds_item");
                dr["ds_item"] = "Nenhum";
                _dt_src.Rows.Add(dr);
            }

            _dt.DataSource = _dt_src;
            _dt.DataBind();
        }
    }
}